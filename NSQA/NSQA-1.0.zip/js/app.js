(function(window){
	var app = function (){
		this.resIndex = 0;
		this.res = {};
		Object.defineProperty(this.res, "length", {
			value: 0,
            writable: true,
            enumerable: false,
            configurable: false
		});
		this._onload = function (){};
		this._loaded = function (){};
	}
	app.prototype.run = function(func){
		func(this);
	}
	app.prototype.registRes = function (name, src) {
		if (this.res[name] !== undefined ) {
			console.info("app got registered resource");
			return;
		}
		this.res[name] = src;
		this.res.length++;
	}
	app.prototype.initial = function (callback) {
		var res = this.res;
		for(var r in res){
			var img = new Image();
			img.setAttribute("src", res[r]);
			img.onload = _onload.bind(this);

			function _onload(){
				this.res[r] = img;
				this.resIndex++;
				callback((this.resIndex/this.res.length).toFixed(2));
				if(this.resIndex === this.res.length) {
					this._onload;
					this._loaded;
				}
			};
		}
	}
	app.prototype.onload = function(func){
		this._onload = func;
	}
	app.prototype.loaded = function(func){
		this._loaded = func;
	}

	window.app = (function(){
		return new app();
	}).call(this);
})(window);